package A20210415.E1;

import java.util.List;

public interface DataElement {
    /**
     *
     * @param elements = a list with the elements to stract
     * @return the element needed
     */
    public String extract(List<String> elements);
}
